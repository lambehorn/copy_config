## + Положительное предложение
[[Subject]] + [[Verb]] 2\ed 
Arseniy swam in the lake yesterday.

## - Отрицательное предложение
[[Subject]] + didn\`t  + [[Verb]]
Arseniy did\`t swim in the lake yesterday.

## ? Вопросительное прделожение
Did + [[Subject]] + [[Verb]]
Did Arseniy swim in the lake yesterday.

## Слова [[Маркеры]]
yesterday, last. in + (time), ago