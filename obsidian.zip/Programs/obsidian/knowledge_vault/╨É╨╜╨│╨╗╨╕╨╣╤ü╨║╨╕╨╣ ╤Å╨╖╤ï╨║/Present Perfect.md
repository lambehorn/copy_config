## + Положительное предложение
[[Subject]] + have\has + [[Verb]] 3\ed
Vlad has already played a new game.

## - Отрицательное предложение
[[Subject]] + have\has + not + [[Verb]] 3\ed
Vlad hasn\`t played a new game yet.

## ? Вопросительное прделожение
have\has + [[Subject]] + [[Verb]] 3\ed
Has Vlad already played a new game.

## Слова [[Маркеры]]
already, yet, just, never, ever, for, since