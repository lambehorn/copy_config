## + Положительное предложение
[[Subject]] + [[Verb]]-s/-es 
He does to the swim every day
## - Отрицательное предложение
[[Subject]] + do/does + not + [[Verb]]
I don`t work
## ? Вопросительное прделожение
Do/Does + [[Subject]] + [[Verb]]
Does she swim every day

## Слова [[Маркеры]]
always, usually, ever, every, never ...
## Глаголы [[Маркеры]]
Like, love, know, hate ... (выражение чувства)