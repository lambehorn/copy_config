## + Положительное предложение
[[Subject]] + am/is/are + [[Verb]]-ing
He\`s using a computer for his job

## - Отрицательное предложение
[[Subject]] +  am/is/are + not + [[Verb]]-ing
Ivan isn\`t drive car

## ? Вопросительное прделожение
am/is/are + [[Subject]] + [[Verb]]-ing
Are they driving tomorrow 

## Слова [[Маркеры]]
now, right, at present, at the moment
