Личный профиль (lambehorn):
vless://b1196444-490c-4b7b-b036-a034f0bd8b7a@188.130.154.165:15369?type=tcp&security=reality&pbk=la3foKmy052rb5cZ1c8-fm-MAP1EoHMNJajnazUt9kc&fp=chrome&sni=cloudflare.com&sid=98d8&spx=%2F#lambehorn

Общий профиль (vpn):
vless://11b913ef-2aaa-4db3-834e-29764c540bac@188.130.154.165:15369?type=tcp&security=reality&pbk=la3foKmy052rb5cZ1c8-fm-MAP1EoHMNJajnazUt9kc&fp=chrome&sni=cloudflare.com&sid=98d8&spx=%2F#vpn