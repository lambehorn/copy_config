#!/bin/bash
pid=$(hyprctl activewindow -j | jq -r '.pid')
if [ -n "$pid" ]; then
    kill -15 "$pid"
fi
