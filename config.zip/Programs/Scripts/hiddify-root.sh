#!/bin/sh
exec pkexec env \
  DISPLAY="$DISPLAY" \
  XAUTHORITY="$XAUTHORITY" \
  WAYLAND_DISPLAY="$WAYLAND_DISPLAY" \
  XDG_RUNTIME_DIR="$XDG_RUNTIME_DIR" \
  /usr/bin/hiddify

