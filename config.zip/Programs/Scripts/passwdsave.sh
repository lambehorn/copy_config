#!/bin/bash
python /home/ivanbaran/Projects/passwdSave/main.py
